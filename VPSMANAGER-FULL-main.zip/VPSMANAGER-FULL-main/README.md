# VPSMANAGER
SCRIPT GERENCIADOR SSH FULL


apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/RodrigoNelson/VPSMANAGER-FULL/main/Plus; chmod 777 Plus;./Plus
